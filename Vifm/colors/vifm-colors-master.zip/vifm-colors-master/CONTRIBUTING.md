When opening a PR that adds a new theme please include a screenshot.

When opening a PR that changes the look of a theme please include a before and after screenshot.
